JS Libraries
============

Protovis
--------

[Protovis](http://vis.stanford.edu/protovis/) is a javascript data visualization library.

Protovis is free and open source, provided under th [BSD License](http://www.opensource.org/licenses/bsd-license.php).

The file provided here is the compressed javascript library. I will endeavour to ensure that it is the latest stable version.

Sean Carmody.
